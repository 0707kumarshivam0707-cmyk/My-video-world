// Edit the sample videos below to add your own. A YouTube video ID is the part after "v=" in a watch URL.
const videos = [
  {title:"Simple Things That Make Life Beautiful", category:"Vlogs", id:"ScMzIvxBSi4", image:"https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"},
  {title:"A Beautiful Place to Explore", category:"Travel", id:"ysz5S6PUM-U", image:"https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"},
  {title:"Learn Something New Today", category:"Education", id:"jNQXAC9IVRw", image:"https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"},
  {title:"Gaming Highlights and Fun Moments", category:"Gaming", id:"aqz-KE-bpKQ", image:"https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"},
  {title:"My Favourite Tech and Gadgets", category:"Tech", id:"dQw4w9WgXcQ", image:"https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"},
  {title:"Easy Food Ideas to Try at Home", category:"Food", id:"kJQP7kiw5Fk", image:"https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"},
  {title:"A Quick Everyday Vlog", category:"Vlogs", id:"L_jWHffIx5E", image:"https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"},
  {title:"Discover the World Around You", category:"Travel", id:"tgbNymZ7vqY", image:"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=800&q=80", views:"Sample video", date:"Add your upload"}
];

const grid = document.getElementById("videoGrid");
const searchInput = document.getElementById("searchInput");
const resultCount = document.getElementById("resultCount");
const emptyState = document.getElementById("emptyState");
let activeCategory = "All";

function renderVideos() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = videos.filter(video => {
    const matchesCategory = activeCategory === "All" || video.category === activeCategory;
    const matchesSearch = `${video.title} ${video.category}`.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });
  grid.innerHTML = filtered.map(video => `
    <article class="video-card">
      <button class="video-thumb video-open" data-video="${video.id}" aria-label="Play ${escapeHtml(video.title)}">
        <img src="${video.image}" alt="${escapeHtml(video.title)}" loading="lazy">
        <span class="play-small">▶</span>
      </button>
      <div class="category-label">${escapeHtml(video.category)}</div>
      <h3>${escapeHtml(video.title)}</h3>
      <div class="meta">${escapeHtml(video.views)} · ${escapeHtml(video.date)}</div>
    </article>
  `).join("");
  resultCount.textContent = `${filtered.length} videos`;
  emptyState.hidden = filtered.length > 0;
  document.querySelectorAll(".video-open").forEach(button => {
    button.addEventListener("click", () => openVideo(button.dataset.video));
  });
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[char]));
}
const modal = document.getElementById("videoModal");
const frame = document.getElementById("videoFrame");
function openVideo(id) {
  frame.src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?autoplay=1&rel=0`;
  modal.hidden = false;
  document.body.style.overflow = "hidden";
  document.getElementById("closeModal").focus();
}
function closeVideo() {
  modal.hidden = true;
  frame.src = "";
  document.body.style.overflow = "";
}
searchInput.addEventListener("input", renderVideos);
document.querySelectorAll(".category").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".category").forEach(item => item.classList.remove("active"));
    button.classList.add("active");
    activeCategory = button.dataset.category;
    renderVideos();
  });
});
document.getElementById("closeModal").addEventListener("click", closeVideo);
document.getElementById("modalBackdrop").addEventListener("click", closeVideo);
document.addEventListener("keydown", event => { if (event.key === "Escape" && !modal.hidden) closeVideo(); });
document.querySelectorAll(".video-open").forEach(button => button.addEventListener("click", () => openVideo(button.dataset.video)));
renderVideos();
